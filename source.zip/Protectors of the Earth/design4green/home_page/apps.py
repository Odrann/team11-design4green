# HOME PAGE APPS
from django.apps import AppConfig
from django.contrib import admin


class HomePageConfig(AppConfig):
    name = 'home_page'


